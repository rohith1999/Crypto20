package com.rohith.crypto20;

import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.speech.RecognizerIntent;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.app.ShareCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.ayush.imagesteganographylibrary.Text.AsyncTaskCallback.TextEncodingCallback;
import com.ayush.imagesteganographylibrary.Text.ImageSteganography;
import com.ayush.imagesteganographylibrary.Text.TextEncoding;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class Encode extends AppCompatActivity   implements TextEncodingCallback {

    private static final int SELECT_PICTURE = 100;
    private static final int REQ_CODE_SPEECH_INPUT = 200;
    private static final String TAG = "Encode Class";
    //Created variables for UI
    private Toolbar encode_toolbar;
    private TextInputLayout secret_message_layout;
    private ImageButton encode_button;
    private ImageButton save_image_button;
    private TextView whether_encoded;
    private ImageView imageView;
    private TextView message;
    private EditText secret_key;
    //Objects needed for encoding
    private TextEncoding textEncoding;
    private ImageSteganography imageSteganography;
    private ProgressDialog save;
    private Uri filepath;
    //Bitmaps
    private Bitmap original_image;
    private Bitmap encoded_image;
    private File file;
    private String fileEncodedPath;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_encode);

        //initialized the UI components
        secret_message_layout=findViewById(R.id.secret_message_layout);
        whether_encoded = findViewById(R.id.whether_encoded);
        imageView = findViewById(R.id.imageview);
        message = findViewById(R.id.message);
        secret_key = findViewById(R.id.secret_key);

        final ImageButton share_image_button=findViewById(R.id.share_button_decode);
        share_image_button.setEnabled(false);
        share_image_button.setImageResource(R.drawable.ic_share_grey_24dp);

        ImageButton choose_image_button = findViewById(R.id.choose_image_button);
         encode_button = findViewById(R.id.encode_button);
         save_image_button = findViewById(R.id.save_image_button);

        save_image_button.setEnabled(false);
        save_image_button.setImageResource(R.drawable.ic_save_grey_24dp);
        encode_button.setEnabled(false);
        encode_button.setImageResource(R.drawable.ic_enhanced_encryption_grey_24dp);
        secret_message_layout.setEnabled(false);
        secret_message_layout.setStartIconTintList(ColorStateList.valueOf(Color.GRAY));
        secret_message_layout.setEndIconTintList(ColorStateList.valueOf(Color.GRAY));

        encode_toolbar=findViewById(R.id.encode_toolbar);
        setSupportActionBar(encode_toolbar);
        getSupportActionBar().setTitle("Encoder");
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        checkAndRequestPermissions();


        //end Icon click listner
        secret_message_layout.setEndIconOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startVoiceInput();

            }
        });

        //share
        share_image_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                Intent intent = new Intent(Intent.ACTION_SEND);
//                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
//                    Uri apkURI = FileProvider.getUriForFile(getApplicationContext(), getPackageName() + ".provider", file);
//                    Log.d("00000oo",apkURI.toString());
//                    intent.setDataAndType(apkURI, "image/*");
//                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
//                } else {
//                    intent.setDataAndType(Uri.fromFile(file), "image/*");
//                }
//                startActivity(intent);
//

                Uri uri = FileProvider.getUriForFile(getApplicationContext(), getPackageName()+".provider", file);

                Intent intent = ShareCompat.IntentBuilder.from(Encode.this)
                        .setType("image/*")
                       .setSubject("yoyo")
                        .setStream(uri)
                        .setChooserTitle("yoyo")
                        .createChooserIntent()
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);


                startActivity(intent);

            }
        });


        //Choose image button
        choose_image_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImageChooser();
            }
        });

        //Encode Button
        encode_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                whether_encoded.setText("");
                String SECRET=message.getText().toString();
                if (filepath != null) {
                    if (!SECRET.isEmpty()) {


                        String publicKeyString="";
                        String numberString="";
                        SharedPreferences sharedPreferences=getSharedPreferences("settings",MODE_PRIVATE);
                       // String publicKeyString1=sharedPreferences.getString("1",publicKeyString);
                        String numberString1=sharedPreferences.getString("2",numberString);

                        Log.d("nnnnnnnn",numberString1);

                        //ImageSteganography Object instantiation
                        imageSteganography = new ImageSteganography(
                                numberString1+"*"+message.getText().toString().trim(),
                               "RISHIKA",
                                original_image);
                        //TextEncoding object Instantiation
                        textEncoding = new TextEncoding(Encode.this, Encode.this);
                        //Executing the encoding
                        textEncoding.execute(imageSteganography);

                        save_image_button.setEnabled(true);
                        save_image_button.setImageResource(R.drawable.ic_save_black_24dp);

                    }
                    else {
                        whether_encoded.setTextColor(Color.RED);
                        whether_encoded.setText("No Secret Message Entered");
                        save_image_button.setEnabled(false);
                        save_image_button.setImageResource(R.drawable.ic_save_grey_24dp);
                    }
                }
            }
        });

        //Save image button
        save_image_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Bitmap imgToSave = encoded_image;
                Thread PerformEncoding = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        saveToInternalStorage(imgToSave);
                    }
                });
                share_image_button.setEnabled(true);
                share_image_button.setImageResource(R.drawable.ic_share_black_24dp);


                save = new ProgressDialog(Encode.this);
                save.setMessage("Saving, Please Wait...");
                save.setTitle("Saving Image");
                save.setIndeterminate(false);
                save.setCancelable(false);
                save.show();
                PerformEncoding.start();
            }
        });

    }

    private void ImageChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), SELECT_PICTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQ_CODE_SPEECH_INPUT: {
                if (resultCode == RESULT_OK && null != data) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    String text=message.getText().toString();
                    message.setText(text+" "+result.get(0));
                }
                break;
            }

        }

        //Image set to imageView
        if (requestCode == SELECT_PICTURE && resultCode == RESULT_OK && data != null && data.getData() != null) {

            filepath = data.getData();
            Log.d("000000000oo",filepath.toString());
            try {
                original_image = MediaStore.Images.Media.getBitmap(getContentResolver(), filepath);
                encode_button.setEnabled(true);
                encode_button.setImageResource(R.drawable.ic_enhanced_encryption_black_24dp);
                imageView.setImageBitmap(original_image);
                secret_message_layout.setEnabled(true);
                secret_message_layout.setStartIconTintList(ColorStateList.valueOf(Color.BLUE));
                secret_message_layout.setEndIconTintList(ColorStateList.valueOf(Color.BLUE));
                SharedPreferences sharedPreferences=getSharedPreferences("choose_image",MODE_PRIVATE);
                SharedPreferences.Editor editor;
                editor=sharedPreferences.edit();
                editor.putString("3","true");
                editor.apply();
            } catch (IOException e) {
                Log.d(TAG, "Error : " + e);
            }
        }

    }

    // Override method of TextEncodingCallback

    @Override
    public void onStartTextEncoding() {
        //Whatever you want to do at the start of text encoding
    }

    @Override
    public void onCompleteTextEncoding(ImageSteganography result) {

        //By the end of textEncoding

        if (result != null && result.isEncoded()) {
            encoded_image = result.getEncoded_image();
            whether_encoded.setTextColor(Color.GREEN);
            whether_encoded.setText("Encoded");
            imageView.setImageBitmap(encoded_image);
        }
    }

    private void saveToInternalStorage(Bitmap bitmapImage) {
        OutputStream fOut;
        Date currentTime = Calendar.getInstance().getTime();
         file = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS), "Encoded"+ currentTime.toString()+ ".PNG"); // the File to save//
        Log.d("wwwwwwwww",Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS).toString());
        try {
            fOut = new FileOutputStream(file);
            bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fOut); // saving the Bitmap to a file
            fOut.flush(); // Not really required
            fOut.close(); // do not forget to close the stream
            fileEncodedPath=file.getAbsolutePath();
            whether_encoded.post(new Runnable() {
                @Override
                public void run() {
                    save.dismiss();

                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void checkAndRequestPermissions() {
        int permissionWriteStorage = ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int ReadPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);
        List<String> listPermissionsNeeded = new ArrayList<>();
        if (ReadPermission != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (permissionWriteStorage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (!listPermissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this, listPermissionsNeeded.toArray(new String[0]), 1);
        }
    }
    private void startVoiceInput() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Hello, How can I help you?");
        try {
            startActivityForResult(intent, REQ_CODE_SPEECH_INPUT);
        } catch (ActivityNotFoundException a) {

        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        SharedPreferences sharedPreferences=getSharedPreferences("choose_image",MODE_PRIVATE);
        SharedPreferences.Editor editor;
        editor=sharedPreferences.edit();
        editor.putString("3","false");
        editor.apply();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.settings_menu,menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId()==R.id.nav_settings){

            final Dialog dialog=new Dialog(this);

            LayoutInflater inflater = getLayoutInflater();
            View layout = inflater.inflate(R.layout.setttings_dailog, null);

            dialog.setContentView(R.layout.setttings_dailog);
            Window window = dialog.getWindow();
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            window.setGravity(Gravity.CENTER);
            dialog.show();

            String publicKeyString="";
            String numberString="";
            SharedPreferences sharedPreferences=getSharedPreferences("settings",MODE_PRIVATE);
            String publicKeyString1=sharedPreferences.getString("1",publicKeyString);
            String numberString1=sharedPreferences.getString("2",numberString);



            final TextInputEditText publicText=dialog.findViewById(R.id.public_key_text);
            final MaterialAutoCompleteTextView numberText=dialog.findViewById(R.id.dialog_number_text);
            Button apply=dialog.findViewById(R.id.apply_dialog_button);

            publicText.setTransformationMethod(new PasswordTransformationMethod());

            String[] items=new String[]{"1","2","3","4","5"};

            ArrayAdapter<String> adapter=new ArrayAdapter<String>(Encode.this,R.layout.drop_down_text,items);
            numberText.setAdapter(adapter);


            if (!publicKeyString1.isEmpty() && !numberString1.isEmpty()){

                publicText.setText(publicKeyString1);
                numberText.setText(numberString1);

            }

            apply.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                   String publicKeyString= publicText.getText().toString();
                    String numberString=numberText.getText().toString();
                    SharedPreferences sharedPreferences=getSharedPreferences("settings",MODE_PRIVATE);
                    SharedPreferences.Editor editor;
                    editor=sharedPreferences.edit();
                    editor.putString("1",publicKeyString);
                    editor.putString("2",numberString);
                    editor.apply();
                    dialog.dismiss();

                }
            });



        }



        return super.onOptionsItemSelected(item);
    }
}
