package com.rohith.crypto20;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.ProcessLifecycleOwner;

public class ChoiceActivity extends AppCompatActivity implements LifecycleObserver {

    //fingerPrint
    SharedPreferences sharedPreferences1;
    String BACKGROUND="false";
    String CHOOSE_BACKGROUND="false";
    Intent fingerAuthIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choice);

        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);


        Button encode = findViewById(R.id.encode_button);
        Button decode = findViewById(R.id.decode_button);

        encode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Encode.class));
            }
        });

        decode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Decode.class));
            }
        });

    }

//    @OnLifecycleEvent(Lifecycle.Event.ON_PAUSE)
//    public  void onAppPaused(){
//        SharedPreferences sharedPreferences=getSharedPreferences("fingerprint_decode",MODE_PRIVATE);
//        SharedPreferences.Editor editor;
//        editor=sharedPreferences.edit();
//        editor.putString("1","false");
//        editor.apply();
//    }




    @OnLifecycleEvent(Lifecycle.Event.ON_STOP)
    public void onAppBackgrounded() {
        //App in background
        sharedPreferences1=getSharedPreferences("Store_back",MODE_PRIVATE);
        SharedPreferences.Editor editor;
        editor=sharedPreferences1.edit();
        editor.putString("1","true");
        Log.d("yoyo","entered");
        editor.apply();




    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finishAffinity();

    }

    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    public void onAppForegrounded() {
        // App in foreground
        sharedPreferences1=getSharedPreferences("Store_back",MODE_PRIVATE);
        SharedPreferences sharedPreferences=getSharedPreferences("choose_image",MODE_PRIVATE);
        String CHOOSE_BACKGROUND1=sharedPreferences.getString("3",CHOOSE_BACKGROUND);
        String BACKGROUND1=sharedPreferences1.getString("1",BACKGROUND);
        Log.d("yoyo",BACKGROUND1);

        if (BACKGROUND1.equals("true") && CHOOSE_BACKGROUND1.equals("false")) {
            fingerAuthIntent=new Intent(this, MainActivity.class);
            startActivity(fingerAuthIntent);
            this.finishAffinity();
            SharedPreferences.Editor editor;
            editor=sharedPreferences1.edit();
            editor.putString("1","false");
            editor.apply();
        }



    }


}