
package com.rohith.crypto20;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.KeyguardManager;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.os.Bundle;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyPermanentlyInvalidatedException;
import android.security.keystore.KeyProperties;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

public class MainActivity extends AppCompatActivity {


    private FingerprintManager fingerprintManager;
    private TextView paralabel;
    private ImageView fingerprint;
    private TextView heading;
    private KeyguardManager keyguardManager;
    private KeyStore keyStore;
    private Cipher cipher;
    private String KEY_NAME="AndroidKey";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        paralabel=findViewById(R.id.instruction);
        fingerprint=findViewById(R.id.image);
        heading=findViewById(R.id.heading);

        SharedPreferences sharedPreferences2=getSharedPreferences("fingerprint_decode",MODE_PRIVATE);
        SharedPreferences.Editor editor;
        editor=sharedPreferences2.edit();
        editor.putString("1","false");
        editor.apply();



        //android version greater than or equal to marshmallow
        //check if fingerprint scanner is present
        //permission for fingerprint
        //extra type of lock
        //at least 1 fingerprint is registered


        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.M){

            fingerprintManager=(FingerprintManager)getSystemService(FINGERPRINT_SERVICE);
            keyguardManager=(KeyguardManager)getSystemService(KEYGUARD_SERVICE);
            if (!fingerprintManager.isHardwareDetected()){

                paralabel.setText("Fingerprint not detected");

            }
            else if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.USE_FINGERPRINT)!= PackageManager.PERMISSION_GRANTED){

                paralabel.setText("Permission not granted use");

            }
            else if (!keyguardManager.isKeyguardSecure()){
                paralabel.setText("Add lock to your phone in settings");

            }
            else if (!fingerprintManager.hasEnrolledFingerprints()){
                paralabel.setText("You should add at least one fingerprint");
            }
            else {
                paralabel.setText("Place your Finger on Scanner to access the app");
                generateKey();

                if (cipherInit()) {
                    FingerprintManager.CryptoObject cryptoObject=new FingerprintManager.CryptoObject(cipher);
                    FingerPrintHandler fingerPrintHandler = new FingerPrintHandler(this,null,null,null,null);
                    fingerPrintHandler.startAuth(fingerprintManager, cryptoObject);
                }
            }

        }
    }

    @TargetApi(Build.VERSION_CODES.M)
    private void generateKey() {

        try {

            keyStore = KeyStore.getInstance("AndroidKeyStore");
            KeyGenerator keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");

            keyStore.load(null);
            keyGenerator.init(new
                    KeyGenParameterSpec.Builder(KEY_NAME,
                    KeyProperties.PURPOSE_ENCRYPT |
                            KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_CBC)
                    .setUserAuthenticationRequired(true)
                    .setEncryptionPaddings(
                            KeyProperties.ENCRYPTION_PADDING_PKCS7)
                    .build());
            keyGenerator.generateKey();

        } catch (KeyStoreException | IOException | CertificateException
                | NoSuchAlgorithmException | InvalidAlgorithmParameterException
                | NoSuchProviderException e) {

            e.printStackTrace();

        }

    }


    @TargetApi(Build.VERSION_CODES.M)
    public boolean cipherInit() {
        try {
            cipher = Cipher.getInstance(KeyProperties.KEY_ALGORITHM_AES + "/" + KeyProperties.BLOCK_MODE_CBC
                    + "/" + KeyProperties.ENCRYPTION_PADDING_PKCS7);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
            throw new RuntimeException("Failed to get Cipher", e);
        }


        try {

            keyStore.load(null);

            SecretKey key = (SecretKey) keyStore.getKey(KEY_NAME,
                    null);

            cipher.init(Cipher.ENCRYPT_MODE, key);

            return true;

        } catch (KeyPermanentlyInvalidatedException e) {
            return false;
        } catch (KeyStoreException | CertificateException | UnrecoverableKeyException | IOException | NoSuchAlgorithmException | InvalidKeyException e) {
            throw new RuntimeException("Failed to init Cipher", e);
        }

    }

}
