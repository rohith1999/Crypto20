package com.rohith.crypto20;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.hardware.fingerprint.FingerprintManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyPermanentlyInvalidatedException;
import android.security.keystore.KeyProperties;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.OnLifecycleEvent;


import com.ayush.imagesteganographylibrary.Text.AsyncTaskCallback.TextDecodingCallback;
import com.ayush.imagesteganographylibrary.Text.AsyncTaskCallback.TextEncodingCallback;
import com.ayush.imagesteganographylibrary.Text.ImageSteganography;
import com.ayush.imagesteganographylibrary.Text.TextDecoding;
import com.ayush.imagesteganographylibrary.Text.TextEncoding;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URI;
import java.nio.InvalidMarkException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.Calendar;
import java.util.Date;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

public class Decode extends AppCompatActivity implements TextDecodingCallback {

    private static final int SELECT_PICTURE = 100;
    private static final String TAG = "Decode Class";
    //Initializing the UI components
    private ImageButton choose_image_button;
    private ImageButton decode_button;

    private Toolbar decode_toolbar;
    private TextView textView;
    private ImageView imageView;
    private TextView message;
    private EditText secret_key;
    private Uri filepath;
    //Bitmap
    private Bitmap original_image;
    //fingerPrint
    private TextView paralabel;
    private ImageView fingerprint;
    private TextView heading;
    private FingerprintManager fingerprintManager;
    private KeyguardManager keyguardManager;
    private KeyStore keyStore;
    private Cipher cipher;
    private String KEY_NAME="AndroidKey";
    private String fingerPrintDecode="true";
    private String SECRET_MESSAGE;
    private String imageName;
    private String path;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_decode);

        //fingerPrint
        paralabel=findViewById(R.id.instruction_finger_decode);
        fingerprint=findViewById(R.id.image_finger_decode);
        heading=findViewById(R.id.heading_finger_decode);

        paralabel.setVisibility(View.INVISIBLE);
        fingerprint.setVisibility(View.INVISIBLE);
        heading.setVisibility(View.INVISIBLE);

        SharedPreferences sharedPreferences=getSharedPreferences("fingerprint_decode",MODE_PRIVATE);
        SharedPreferences.Editor editor;
        editor=sharedPreferences.edit();
        editor.putString("1",fingerPrintDecode);
        editor.apply();

      //  Log.d("finger_decode1",fingerPrintDecode);

//......................................
        decode_toolbar=findViewById(R.id.decode_toolbar);
        setSupportActionBar(decode_toolbar);
        getSupportActionBar().setTitle("Decode");
       // getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //Instantiation of UI components
        textView = findViewById(R.id.whether_decoded);

        imageView = findViewById(R.id.imageview);
        message = findViewById(R.id.message);
        secret_key = findViewById(R.id.secret_key);


        choose_image_button = findViewById(R.id.choose_image_button);
        decode_button = findViewById(R.id.decode_button);

        decode_button.setEnabled(false);
        decode_button.setImageResource(R.drawable.ic_lock_grey_24dp);

        //Choose Image Button
        choose_image_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImageChooser();
            }
        });

        //Decode Button
        decode_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (filepath != null) {


                    //Making the ImageSteganography object
                    ImageSteganography imageSteganography = new ImageSteganography(secret_key.getText().toString(),
                            original_image);

                    //Making the TextDecoding object
                    TextDecoding textDecoding = new TextDecoding(Decode.this, Decode.this);

                    //Execute Task
                    textDecoding.execute(imageSteganography);
                }
            }
        });


    }

    private void ImageChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), SELECT_PICTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        //Image set to imageView
        if (requestCode == SELECT_PICTURE && resultCode == RESULT_OK && data != null && data.getData() != null) {

            filepath = data.getData();

            //fileName

            Cursor returnCursor =
                    getContentResolver().query(filepath, null, null, null, null);
            /*
             * Get the column indexes of the data in the Cursor,
             * move to the first row in the Cursor, get the data,
             * and display it.
             */
            int nameIndex = returnCursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
            returnCursor.moveToFirst();
            imageName=returnCursor.getString(nameIndex);

            path = FileUtils.getPath(this, filepath);
            Log.d("999999999999",path);
            //filepath

            try {
                original_image = MediaStore.Images.Media.getBitmap(getContentResolver(), filepath);
                imageView.setImageBitmap(original_image);
                decode_button.setEnabled(true);
                decode_button.setImageResource(R.drawable.ic_lock_black_24dp);
                SharedPreferences sharedPreferences=getSharedPreferences("choose_image",MODE_PRIVATE);
                SharedPreferences.Editor editor;
                editor=sharedPreferences.edit();
                editor.putString("3","true");
                editor.apply();


            } catch (IOException e) {
                Log.d(TAG, "Error : " + e);
            }
        }

    }

    @Override
    public void onStartTextEncoding() {
        //Whatever you want to do by the start of textDecoding
    }

    @Override
    public void onCompleteTextEncoding(ImageSteganography result) {

        //By the end of textDecoding
        textView.setTextColor(Color.GRAY);
        if (result != null) {


            if (!result.isDecoded())

                textView.setText("No message found");

            else {

                if (!result.isSecretKeyWrong()) {

                    paralabel.setVisibility(View.VISIBLE);
                    fingerprint.setImageResource(R.drawable.ic_fingerprint_black_24dp);
                    fingerprint.setVisibility(View.VISIBLE);
                    heading.setVisibility(View.VISIBLE);
                    SECRET_MESSAGE=result.getMessage();
                    fingerPrintCheck();



                    textView.setTextColor(Color.GREEN);
                    textView.setText("Decoded");


                } else {
                    textView.setTextColor(Color.RED);
                    textView.setText("Wrong secret key");
                }
            }
        }
        else {
            textView.setText("Select Image First");
        }

    }


    //fingerPrint Functions
    @TargetApi(Build.VERSION_CODES.M)
    private void generateKey() {

        try {

            keyStore = KeyStore.getInstance("AndroidKeyStore");
            KeyGenerator keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");

            keyStore.load(null);
            keyGenerator.init(new
                    KeyGenParameterSpec.Builder(KEY_NAME,
                    KeyProperties.PURPOSE_ENCRYPT |
                            KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_CBC)
                    .setUserAuthenticationRequired(true)
                    .setEncryptionPaddings(
                            KeyProperties.ENCRYPTION_PADDING_PKCS7)
                    .build());
            keyGenerator.generateKey();

        } catch (KeyStoreException | IOException | CertificateException
                | NoSuchAlgorithmException | InvalidAlgorithmParameterException
                | NoSuchProviderException e) {

            e.printStackTrace();

        }

    }


    @TargetApi(Build.VERSION_CODES.M)
    public boolean cipherInit() {
        try {
            cipher = Cipher.getInstance(KeyProperties.KEY_ALGORITHM_AES + "/" + KeyProperties.BLOCK_MODE_CBC + "/" + KeyProperties.ENCRYPTION_PADDING_PKCS7);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
            throw new RuntimeException("Failed to get Cipher", e);
        }


        try {

            keyStore.load(null);

            SecretKey key = (SecretKey) keyStore.getKey(KEY_NAME,
                    null);

            cipher.init(Cipher.ENCRYPT_MODE, key);

            return true;

        } catch (KeyPermanentlyInvalidatedException e) {
            return false;
        } catch (KeyStoreException | CertificateException | UnrecoverableKeyException | IOException | NoSuchAlgorithmException | InvalidKeyException e) {
            throw new RuntimeException("Failed to init Cipher", e);
        }

    }

    public void fingerPrintCheck(){
        //android version greater than or equal to marshmallow
        //check if fingerprint scanner is present
        //permission for fingerprint
        //extra type of lock
        //at least 1 fingerprint is registered


        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.M){

            fingerprintManager=(FingerprintManager)getSystemService(FINGERPRINT_SERVICE);
            keyguardManager=(KeyguardManager)getSystemService(KEYGUARD_SERVICE);
            if (!fingerprintManager.isHardwareDetected()){

                paralabel.setText("Fingerprint not detected");

            }
            else if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.USE_FINGERPRINT)!= PackageManager.PERMISSION_GRANTED){

                paralabel.setText("Permission not granted use");

            }
            else if (!keyguardManager.isKeyguardSecure()){
                paralabel.setText("Add lock to your phone in settings");

            }
            else if (!fingerprintManager.hasEnrolledFingerprints()){
                paralabel.setText("You should add at least one fingerprint");
            }
            else {
                paralabel.setText("Place your Finger on Scanner to access the app");
                generateKey();

                if (cipherInit()) {
                    FingerprintManager.CryptoObject cryptoObject=new FingerprintManager.CryptoObject(cipher);
                    FingerPrintHandler fingerPrintHandler = new FingerPrintHandler(this,SECRET_MESSAGE,original_image,path,imageName);
                    fingerPrintHandler.startAuth(fingerprintManager, cryptoObject);

                }
            }

        }


    }




    @Override
    protected void onResume() {
        super.onResume();
        SharedPreferences sharedPreferences=getSharedPreferences("choose_image",MODE_PRIVATE);
        SharedPreferences.Editor editor;
        editor=sharedPreferences.edit();
        editor.putString("3","false");
        editor.apply();
    }




}
