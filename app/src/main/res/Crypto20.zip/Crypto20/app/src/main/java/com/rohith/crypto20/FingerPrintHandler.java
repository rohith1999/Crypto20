package com.rohith.crypto20;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.hardware.fingerprint.FingerprintManager;
import android.media.Image;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.ayush.imagesteganographylibrary.Text.AsyncTaskCallback.TextDecodingCallback;
import com.ayush.imagesteganographylibrary.Text.AsyncTaskCallback.TextEncodingCallback;
import com.ayush.imagesteganographylibrary.Text.ImageSteganography;
import com.ayush.imagesteganographylibrary.Text.TextEncoding;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Calendar;
import java.util.Date;

import static android.content.Context.MODE_PRIVATE;


@TargetApi(Build.VERSION_CODES.M)
public class FingerPrintHandler extends FingerprintManager.AuthenticationCallback implements TextEncodingCallback {

    private Context context;
    private String message;
    CancellationSignal cancellationSignal;
    String fingerPrintDecode = "false";
    String displayed_once="false";
    private String fingerPrintDecode1;
    SharedPreferences sharedPreferences;
    Bitmap original_image;
    ImageView imageView;
    Bitmap encoded_image;
    String filepath;
    String imageName;
    ImageSteganography imageSteganography;

    public FingerPrintHandler(Context context, String message, Bitmap original_image,String filepath,String imageName) {
        sharedPreferences=context.getSharedPreferences("fingerprint_decode",MODE_PRIVATE);
        fingerPrintDecode1=sharedPreferences.getString("1",fingerPrintDecode);
        this.context=context;
        this.message=message;
        this.original_image=original_image;
        this.filepath=filepath;
        this.imageName=imageName;

    }
    public void startAuth(FingerprintManager fingerprintManager, FingerprintManager.CryptoObject cryptoObject){

         cancellationSignal=new CancellationSignal();
        fingerprintManager.authenticate(cryptoObject,cancellationSignal ,0,this,null);

    }

    @Override
    public void onAuthenticationError(int errorCode, CharSequence errString) {


        if (fingerPrintDecode1.equals("true")){
            this.updateDecode("There was an Authentication error. " + errString, false);

        }
        else {
            this.update("There was an Authentication error. " + errString, false);
            cancellationSignal.cancel();
        }
    }

    @Override
    public void onAuthenticationFailed() {
        if (fingerPrintDecode1.equals("true")) {
            this.updateDecode("Authentication failed. ", false);

        } else {
            this.update("Authentication failed. ", false);
        }
    }

    @Override
    public void onAuthenticationHelp(int helpCode, CharSequence helpString) {
        if (fingerPrintDecode1.equals("true")) {
            this.updateDecode("Error: " + helpString, false);
        } else {
            this.update("Error: " + helpString, false);

        }
    }

    @Override
    public void onAuthenticationSucceeded(FingerprintManager.AuthenticationResult result) {


        if (fingerPrintDecode1.equals("true")) {

            this.updateDecode("You can now access the app", true);

        }


        else {

            this.update("You can now access the app", true);
            Intent decodeIntent = new Intent(context, ChoiceActivity.class);
            context.startActivity(decodeIntent);

        }

    }

    private void update(String s, boolean bool){

        TextView paralabel=((Activity)context).findViewById(R.id.instruction);
        ImageView fingerprint=((Activity)context).findViewById(R.id.image);

        paralabel.setText(s);

        if (!bool){

            paralabel.setTextColor(Color.RED);

        }
        else {

            paralabel.setTextColor(Color.BLACK);
            fingerprint.setImageResource(R.drawable.ic_done_black_24dp);


        }

    }
    private void updateDecode(String s, boolean bool){

        TextView paralabel=((Activity)context).findViewById(R.id.instruction_finger_decode);
        ImageView fingerprint=((Activity)context).findViewById(R.id.image_finger_decode);
        TextView messageView=((Activity)context).findViewById(R.id.message_decode);
        TextView heading_fingerprint=((Activity)context).findViewById(R.id.heading_finger_decode);

        imageView=((Activity)context).findViewById(R.id.imageview);

        int differentiator=message.indexOf("*");
        String messageExtract=message.substring(differentiator+1);

        String numberString1=message.substring(0,differentiator);
        Log.d("iiiiii",numberString1);
        Log.d("iii",messageExtract);
        int number=Integer.parseInt(numberString1);

        if (number!=0){
            messageView.setText(messageExtract);
            number=number-1;
            numberString1=String.valueOf(number);
            Log.d("iiiiiinum",numberString1);
              imageSteganography = new ImageSteganography(
                    numberString1+"*"+messageExtract,
                    "RISHIKA",
                    original_image);

        }
        else {

            messageView.setTextColor(Color.RED);
            messageView.setText("You can't view the message anymore ");
              imageSteganography = new ImageSteganography(
                    numberString1+"*"+" ",
                    "RISHIKA",
                    original_image);

        }



        //encode


        //TextEncoding object Instantiation
      TextEncoding  textEncoding = new TextEncoding(((Activity)context), this);
        //Executing the encoding
        textEncoding.execute(imageSteganography);

        //save


        paralabel.setText(s);
        if (!bool){
            paralabel.setTextColor(Color.RED);
        }
        else {

                paralabel.setTextColor(Color.BLACK);
                fingerprint.setImageResource(R.drawable.ic_done_black_24dp);

                fingerprint.setVisibility(View.INVISIBLE);
                paralabel.setVisibility(View.INVISIBLE);
                heading_fingerprint.setVisibility(View.INVISIBLE);



            //encode again...............
            //ImageSteganography Object instantiation

        }

    }


    @Override
    public void onStartTextEncoding() {

    }

    @Override
    public void onCompleteTextEncoding(ImageSteganography result) {


        if (result != null && result.isEncoded()) {
            encoded_image = result.getEncoded_image();
            imageView.setImageBitmap(encoded_image);
            saveToInternalStorage(encoded_image);

        }

    }


    private void saveToInternalStorage(Bitmap bitmapImage) {
        OutputStream fOut;
        Log.d("]]]]]]]",filepath);
        File file = new File(filepath); // the File to save ,
        try {
            fOut = new FileOutputStream(file);
            bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fOut); // saving the Bitmap to a file
            fOut.flush(); // Not really required
            fOut.close(); // do not forget to close the stream

        } catch (IOException e) {
            e.printStackTrace();
            Log.d("!!!!!!",e.getMessage());
        }
    }
}
